const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const userFile = path.join(__dirname, '../data/credentials.json');

const loadUsers = () => {
  if (!fs.existsSync(userFile)) return {};
  return JSON.parse(fs.readFileSync(userFile));
};

const saveUsers = (data) => {
  fs.writeFileSync(userFile, JSON.stringify(data, null, 2));
};

router.post('/register', (req, res) => {
  const { email, password } = req.body;
  const users = loadUsers();
  if (users[email]) {
    return res.status(409).json({ message: 'User already exists.' });
  }
  users[email] = { password };
  saveUsers(users);
  res.status(201).json({ message: 'Registered successfully', userId: email });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = loadUsers();
  if (!users[email] || users[email].password !== password) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  res.status(200).json({ message: 'Login successful', userId: email });
});

module.exports = router;