const express = require('express');
const cors = require('cors');
const app = express();
const authRoutes = require('./routes/auth');
const progressRoutes = require('./routes/progress');

app.use(cors());
app.use(express.json());
app.use('/api/users', authRoutes);
app.use('/api', progressRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Auth server running on port ${PORT}`);
});